from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        self.width = 400
        self.height = 400

        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        frame1 = Frame(window)
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)

        self.order = StringVar()
        Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)

        Button(frame1, text="Display Koch Snowflake",
               command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")

        order = int(self.order.get())

        # Define triangle points
        p1 = (100, 300)
        p2 = (300, 300)
        p3 = (200, 100)

        # Draw 3 Koch curves
        self.drawKoch(order, p1, p2)
        self.drawKoch(order, p2, p3)
        self.drawKoch(order, p3, p1)

    def drawKoch(self, order, p1, p2):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
        else:
            # Divide line into 3 parts
            x1, y1 = p1
            x2, y2 = p2

            dx = (x2 - x1) / 3
            dy = (y2 - y1) / 3

            pA = (x1, y1)
            pB = (x1 + dx, y1 + dy)
            pD = (x1 + 2 * dx, y1 + 2 * dy)
            pE = (x2, y2)

            # Calculate peak of triangle
            angle = math.radians(60)
            px = pB[0] + (dx * math.cos(angle) - dy * math.sin(angle))
            py = pB[1] + (dx * math.sin(angle) + dy * math.cos(angle))
            pC = (px, py)

            # Recursive calls
            self.drawKoch(order - 1, pA, pB)
            self.drawKoch(order - 1, pB, pC)
            self.drawKoch(order - 1, pC, pD)
            self.drawKoch(order - 1, pD, pE)


KochSnowflake()