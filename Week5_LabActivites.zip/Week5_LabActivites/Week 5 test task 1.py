def sum_of_natural_numbers_iterative(n):
    total = 0
    
    for i in range(1, n + 1):
        total += i
        
        
    return total


result = sum_of_natural_numbers_iterative(5)
print("Sum of first 5 natural numbers:", result)  




def fibonacci_iterative(n):
    
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    
    a = 0
    b = 1
    
    for i in range(2, n + 1):
        c = a + b
        a = b 
        b = c

        
    return b 
    
    
result = fibonacci_iterative(7)
print("the 7th fibonacci number is:", result)



def factorial_iterative(n):
    
    result = 1
    for i in range(1, n + 1):
        result *= i
        
    return result


num = 5
result = factorial_iterative(num)
print("the factorial of", num, "is:", result)        
    
        
    
    