count = 0  # global variable to count moves

def main():
    global count
    n = eval(input("Enter number of disks: "))
    
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    
    print("Number of moves is", count)


def moveDisks(n, fromTower, toTower, auxTower):
    global count
    
    if n == 1:  # Stopping condition
        print("Move disk", n, "from", fromTower, "to", toTower)
        count += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        count += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)


main()  # Call the main function